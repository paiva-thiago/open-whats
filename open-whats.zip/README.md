# OpenWhats

SPA besta pra abrir mensagem no whatsapp sem precisar adicionar

## Acessando



## Credits

[Thiago Paiva](http://www.thiagopaiva.com)

Tnx  [marcograhl/tailwindcss-svelte-starter](https://github.com/marcograhl/tailwindcss-svelte-starter)
