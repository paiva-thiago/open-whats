<script>
    export let titulo;
</script>
<style>
    nav{
        margin-bottom:20px;
    }
</style>
<nav class="flex items-center justify-between bg-teal-500 p-6">
  <div class="flex w-500 items-center flex-shrink-0 text-white mr-6">    
    <span class="font-semibold text-xl tracking-tight">{titulo}</span>
  </div>  
</nav>