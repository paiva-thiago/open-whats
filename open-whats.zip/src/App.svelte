<script>
  import Button   from './Button.svelte'
  import Phone    from './Phone.svelte'
  import Head     from './Head.svelte'
  let tit   = 'OpenWhats';
  let ddi   = '';
  let phone = '';
  const abreZap = ()=>{
    if((ddi.trim()!='')&&(phone.trim()!='')){
      window.open(`https://api.whatsapp.com/send?phone=${ddi}${phone}`);       
    } 
  }
</script>

<svelte:head>
<title>{tit}</title>
</svelte:head>

<main>
  <Head titulo={tit}/>
  <Phone bind:ddi={ddi} bind:phone={phone}/>
  <Button open={abreZap} />
</main>
